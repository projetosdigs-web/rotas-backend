import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";

const API_BASE = "http://127.0.0.1:8000";

const WEEKDAYS = {
  0: "Segunda",
  1: "Terça",
  2: "Quarta",
  3: "Quinta",
  4: "Sexta",
  5: "Sábado",
  6: "Domingo",
};

// Ícone padrão do Leaflet
const cityIcon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

// ======================== LOGIN SCREEN ========================

function LoginScreen({ onLoginSuccess }) {
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("123456");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!username.trim() || !password.trim()) {
      setError("Informe usuário e senha.");
      return;
    }

    setLoading(true);
    try {
      const resp = await fetch(`${API_BASE}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim(), password }),
      });

      if (!resp.ok) {
        setError("Usuário ou senha incorretos.");
        return;
      }

      const data = await resp.json();
      if (!data.access_token) {
        setError("Token inválido retornado pelo servidor.");
        return;
      }

      onLoginSuccess(data.access_token);
    } catch (err) {
      console.error(err);
      setError("Não foi possível conectar ao servidor.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl shadow-black/40 p-6 space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/20 border border-emerald-400/60 text-2xl">
            🚚
          </div>
          <h1 className="text-2xl font-bold">Sistema de Rotas</h1>
          <p className="text-sm text-slate-400">
            Faça login para acessar o painel de consulta e administração.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm text-slate-300 mb-1">
              Usuário
            </label>
            <input
              type="text"
              value={username}
              autoComplete="username"
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <div>
            <label className="block text-sm text-slate-300 mb-1">
              Senha
            </label>
            <input
              type="password"
              value={password}
              autoComplete="current-password"
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {error && (
            <div className="rounded-lg bg-red-900/70 text-red-50 text-sm px-3 py-2">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 disabled:opacity-70 disabled:cursor-not-allowed text-slate-950 transition"
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </form>

        <p className="text-[11px] text-slate-500 text-center">
          Usuário padrão: <span className="font-mono">admin</span> — Senha:{" "}
          <span className="font-mono">123456</span>
        </p>
      </div>
    </div>
  );
}

// ======================== MAPA ========================

function RouteCitiesMap({ data }) {
  const valid = (data || []).filter(
    (item) => item.latitude != null && item.longitude != null
  );

  if (valid.length === 0) {
    return (
      <p className="text-sm text-slate-400">
        Não há cidades/bairros com coordenadas cadastradas para exibir no mapa.
      </p>
    );
  }

  const center = [valid[0].latitude, valid[0].longitude];

  return (
    <div className="mt-3 h-80 w-full rounded-xl overflow-hidden border border-slate-800">
      <MapContainer
        center={center}
        zoom={9}
        style={{ height: "100%", width: "100%" }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution="&copy; OpenStreetMap contributors"
        />
        {valid.map((item, idx) => (
          <Marker
            key={idx}
            position={[item.latitude, item.longitude]}
            icon={cityIcon}
          >
            <Popup>
              <div className="space-y-1 text-sm">
                <div>
                  <strong>
                    {item.city_name}
                    {item.neighborhood_name
                      ? ` - ${item.neighborhood_name}`
                      : ""}
                  </strong>
                  <br />
                  Rota: {item.route_name}
                  <br />
                  Dia: {WEEKDAYS[item.weekday] ?? item.weekday}
                  {item.vehicle_name && (
                    <>
                      <br />
                      Caminhão: {item.vehicle_name}
                      {item.vehicle_plate ? ` (${item.vehicle_plate})` : ""}
                    </>
                  )}
                </div>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${item.latitude},${item.longitude}`}
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    color: "#22c55e",
                    textDecoration: "underline",
                    fontWeight: 500,
                  }}
                >
                  Abrir no Google Maps
                </a>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}

// ======================== APP PRINCIPAL ========================

function App() {
  const [token, setToken] = useState(() => localStorage.getItem("token") || "");
  const [activeTab, setActiveTab] = useState("consulta");

  // Consulta por cidade/bairro
  const [cityQuery, setCityQuery] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Consulta por dia
  const [weekday, setWeekday] = useState("");
  const [resultByDay, setResultByDay] = useState([]);
  const [loadingDay, setLoadingDay] = useState(false);
  const [errorDay, setErrorDay] = useState("");

  // Admin: rotas / cidades / vínculos / bairros / veículos
  const [routes, setRoutes] = useState([]);
  const [cities, setCities] = useState([]);
  const [links, setLinks] = useState([]);
  const [neighborhoods, setNeighborhoods] = useState([]);
  const [vehicles, setVehicles] = useState([]);

  // Rotas
  const [newRouteName, setNewRouteName] = useState("");
  const [newRouteDesc, setNewRouteDesc] = useState("");
  const [routeMsg, setRouteMsg] = useState("");

  // Cidades
  const [newCityName, setNewCityName] = useState("");
  const [newCityState, setNewCityState] = useState("");
  const [newCityLat, setNewCityLat] = useState("");
  const [newCityLng, setNewCityLng] = useState("");
  const [cityMsg, setCityMsg] = useState("");
  const [citySuggestions, setCitySuggestions] = useState([]);
  const [loadingCityGeo, setLoadingCityGeo] = useState(false);

  // Vínculos
  const [linkRouteId, setLinkRouteId] = useState("");
  const [linkCityId, setLinkCityId] = useState("");
  const [linkNeighborhoodId, setLinkNeighborhoodId] = useState("");
  const [linkWeekday, setLinkWeekday] = useState("");
  const [linkVehicleId, setLinkVehicleId] = useState("");
  const [linkMsg, setLinkMsg] = useState("");

  // Bairros
  const [nbCityId, setNbCityId] = useState("");
  const [nbName, setNbName] = useState("");
  const [nbLat, setNbLat] = useState("");
  const [nbLng, setNbLng] = useState("");
  const [nbMsg, setNbMsg] = useState("");
  const [nbSuggestions, setNbSuggestions] = useState([]);
  const [nbLoading, setNbLoading] = useState(false);

  // Caminhões
  const [newVehicleName, setNewVehicleName] = useState("");
  const [newVehiclePlate, setNewVehiclePlate] = useState("");
  const [vehicleMsg, setVehicleMsg] = useState("");

  const authHeaders = token ? { Authorization: `Bearer ${token}` } : {};

  const getRouteName = (id) => {
    const r = routes.find((r) => r.id === id);
    return r ? r.name : `Rota ${id}`;
  };

  const getCityName = (id) => {
    const c = cities.find((c) => c.id === id);
    if (!c) return `Cidade ${id}`;
    return c.state ? `${c.name} (${c.state})` : c.name;
  };

  const getVehicleName = (id) => {
    if (!id) return "Sem caminhão definido";
    const v = vehicles.find((v) => v.id === id);
    return v ? v.name : `Caminhão ${id}`;
  };

  const getNeighborhoodName = (id) => {
    if (!id) return "Cidade inteira";
    const nb = neighborhoods.find((n) => n.id === id);
    return nb ? nb.name : `Bairro ${id}`;
  };

  // Carregar dados iniciais depois do login
  useEffect(() => {
    if (!token) return;

    const fetchInitialData = async () => {
      try {
        const [
          routesResp,
          citiesResp,
          linksResp,
          neighborhoodsResp,
          vehiclesResp,
        ] = await Promise.all([
          fetch(`${API_BASE}/routes/`),
          fetch(`${API_BASE}/cities/`),
          fetch(`${API_BASE}/route-city-day/`),
          fetch(`${API_BASE}/neighborhoods/`),
          fetch(`${API_BASE}/vehicles/`),
        ]);

        if (routesResp.ok) setRoutes(await routesResp.json());
        if (citiesResp.ok) setCities(await citiesResp.json());
        if (linksResp.ok) setLinks(await linksResp.json());
        if (neighborhoodsResp.ok)
          setNeighborhoods(await neighborhoodsResp.json());
        if (vehiclesResp.ok) setVehicles(await vehiclesResp.json());
      } catch (err) {
        console.error("Erro ao carregar dados iniciais:", err);
      }
    };

    fetchInitialData();
  }, [token]);

  // ===== LOGIN / LOGOUT =====

  const handleLoginSuccess = (newToken) => {
    setToken(newToken);
    localStorage.setItem("token", newToken);
  };

  const handleLogout = () => {
    setToken("");
    localStorage.removeItem("token");
    // limpa estados sensíveis
    setRoutes([]);
    setCities([]);
    setLinks([]);
    setNeighborhoods([]);
    setVehicles([]);
    setActiveTab("consulta");
  };

  // ===== CONSULTA: CIDADE/BAIRRO =====
  const handleSearch = async () => {
    setError("");
    setResult(null);

    if (!cityQuery.trim()) {
      setError("Digite o nome de uma cidade ou bairro.");
      return;
    }

    setLoading(true);
    try {
      const resp = await fetch(
        `${API_BASE}/lookup-city/?query=${encodeURIComponent(
          cityQuery.trim()
        )}`
      );

      if (!resp.ok) {
        if (resp.status === 404) {
          setError("Cidade/bairro não encontrado no sistema.");
        } else {
          setError("Erro ao consultar a API.");
        }
        return;
      }

      const data = await resp.json();
      setResult(data);
    } catch (err) {
      console.error(err);
      setError("Não foi possível conectar ao servidor.");
    } finally {
      setLoading(false);
    }
  };

  const handleClearCitySearch = () => {
    setCityQuery("");
    setResult(null);
    setError("");
  };

  // ===== CONSULTA: DIA =====
  const handleSearchByDay = async () => {
    setErrorDay("");
    setResultByDay([]);

    if (weekday === "") {
      setErrorDay("Selecione um dia da semana.");
      return;
    }

    setLoadingDay(true);
    try {
      const resp = await fetch(`${API_BASE}/lookup-day/?weekday=${weekday}`);

      if (!resp.ok) {
        setErrorDay("Erro ao consultar a API.");
        return;
      }

      const data = await resp.json();
      setResultByDay(data);
    } catch (err) {
      console.error(err);
      setErrorDay("Não foi possível conectar ao servidor.");
    } finally {
      setLoadingDay(false);
    }
  };

  const handleClearDaySearch = () => {
    setWeekday("");
    setResultByDay([]);
    setErrorDay("");
  };

  // ===== ADMIN: ROTAS =====
  const handleCreateRoute = async () => {
    setRouteMsg("");

    if (!newRouteName.trim()) {
      setRouteMsg("Informe um nome para a rota.");
      return;
    }

    try {
      const resp = await fetch(`${API_BASE}/routes/`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders },
        body: JSON.stringify({
          name: newRouteName.trim(),
          description: newRouteDesc.trim() || null,
        }),
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        setRouteMsg(
          data?.detail || "Erro ao cadastrar rota (talvez nome duplicado?)."
        );
        return;
      }

      const saved = await resp.json();
      setRoutes((prev) => [...prev, saved]);
      setNewRouteName("");
      setNewRouteDesc("");
      setRouteMsg("Rota cadastrada com sucesso!");
    } catch (err) {
      console.error(err);
      setRouteMsg("Não foi possível conectar ao servidor.");
    }
  };

  const handleDeleteRoute = async (id) => {
    const ok = window.confirm(
      "Tem certeza que deseja excluir esta rota? (remova vínculos antes, se houver)."
    );
    if (!ok) return;

    try {
      const resp = await fetch(`${API_BASE}/routes/${id}`, {
        method: "DELETE",
        headers: { ...authHeaders },
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        alert(
          data?.detail ||
            "Não foi possível excluir a rota. Talvez existam vínculos."
        );
        return;
      }

      setRoutes((prev) => prev.filter((r) => r.id !== id));
      setLinks((prev) => prev.filter((l) => l.route_id !== id));
    } catch (err) {
      console.error(err);
      alert("Erro ao conectar ao servidor.");
    }
  };

  // ===== ADMIN: CIDADES =====
  const handleCreateCity = async () => {
    setCityMsg("");

    if (!newCityName.trim()) {
      setCityMsg("Informe o nome da cidade.");
      return;
    }

    const lat =
      newCityLat.trim() === "" ? null : Number(newCityLat.replace(",", "."));
    const lng =
      newCityLng.trim() === "" ? null : Number(newCityLng.replace(",", "."));

    if (
      (newCityLat.trim() !== "" && Number.isNaN(lat)) ||
      (newCityLng.trim() !== "" && Number.isNaN(lng))
    ) {
      setCityMsg("Latitude/Longitude inválidas.");
      return;
    }

    try {
      const resp = await fetch(`${API_BASE}/cities/`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders },
        body: JSON.stringify({
          name: newCityName.trim(),
          latitude: lat,
          longitude: lng,
        }),
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        setCityMsg(data?.detail || "Erro ao cadastrar cidade.");
        return;
      }

      const saved = await resp.json();
      setCities((prev) => [...prev, saved]);

      setNewCityName("");
      setNewCityState("");
      setNewCityLat("");
      setNewCityLng("");
      setCitySuggestions([]);
      setCityMsg("Cidade cadastrada com sucesso!");
    } catch (err) {
      console.error(err);
      setCityMsg("Não foi possível conectar ao servidor.");
    }
  };

  const handleDeleteCity = async (id) => {
    const ok = window.confirm(
      "Tem certeza que deseja excluir esta cidade? (remova vínculos e bairros antes, se houver)."
    );
    if (!ok) return;

    try {
      const resp = await fetch(`${API_BASE}/cities/${id}`, {
        method: "DELETE",
        headers: { ...authHeaders },
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        alert(
          data?.detail ||
            "Não foi possível excluir a cidade. Talvez existam vínculos ou bairros."
        );
        return;
      }

      setCities((prev) => prev.filter((c) => c.id !== id));
      setLinks((prev) => prev.filter((l) => l.city_id !== id));
      setNeighborhoods((prev) => prev.filter((nb) => nb.city_id !== id));
    } catch (err) {
      console.error(err);
      alert("Erro ao conectar ao servidor.");
    }
  };

  const handleGeocodeCity = async () => {
    setCityMsg("");
    setCitySuggestions([]);

    if (!newCityName.trim()) {
      setCityMsg("Digite o nome da cidade.");
      return;
    }

    setLoadingCityGeo(true);
    try {
      const resp = await fetch(
        `${API_BASE}/geocode/?query=${encodeURIComponent(newCityName.trim())}`
      );

      if (!resp.ok) {
        setCityMsg("Erro ao buscar sugestões.");
        return;
      }

      const data = await resp.json();
      if (!data || data.length === 0) {
        setCityMsg("Nenhuma sugestão encontrada.");
        return;
      }

      setCitySuggestions(data);
    } catch (err) {
      console.error(err);
      setCityMsg("Erro ao conectar ao servidor.");
    } finally {
      setLoadingCityGeo(false);
    }
  };

  const selectCitySuggestion = (s) => {
    setNewCityLat(String(s.latitude));
    setNewCityLng(String(s.longitude));
    setCitySuggestions([]);
    setCityMsg("Coordenadas aplicadas!");
  };

  // ===== ADMIN: BAIRROS =====
  const handleGeocodeNeighborhood = async () => {
    setNbMsg("");
    setNbSuggestions([]);

    if (!nbName.trim()) {
      setNbMsg("Informe o nome do bairro.");
      return;
    }
    if (!nbCityId) {
      setNbMsg("Selecione a cidade do bairro.");
      return;
    }

    const cityObj = cities.find((c) => c.id === Number(nbCityId));
    if (!cityObj) {
      setNbMsg("Cidade inválida.");
      return;
    }

    setNbLoading(true);
    try {
      const url = `${API_BASE}/geocode/?query=${encodeURIComponent(
        nbName.trim()
      )}&city_name=${encodeURIComponent(cityObj.name)}`;

      const resp = await fetch(url);
      if (!resp.ok) {
        setNbMsg("Erro ao buscar coordenadas.");
        return;
      }

      const data = await resp.json();
      setNbSuggestions(data);
      if (!data || data.length === 0) {
        setNbMsg("Nenhuma sugestão encontrada.");
      }
    } catch (err) {
      console.error(err);
      setNbMsg("Não foi possível conectar ao serviço de geocodificação.");
    } finally {
      setNbLoading(false);
    }
  };

  const handleChooseSuggestion = (sug) => {
    setNbLat(String(sug.latitude));
    setNbLng(String(sug.longitude));
    setNbSuggestions([]);
    setNbMsg("Coordenadas preenchidas a partir da sugestão selecionada.");
  };

  const handleCreateNeighborhood = async () => {
    setNbMsg("");

    if (!nbCityId) {
      setNbMsg("Selecione a cidade.");
      return;
    }
    if (!nbName.trim()) {
      setNbMsg("Informe o nome do bairro.");
      return;
    }

    const lat = nbLat.trim() === "" ? null : Number(nbLat.replace(",", "."));
    const lng = nbLng.trim() === "" ? null : Number(nbLng.replace(",", "."));

    if (
      (nbLat.trim() !== "" && Number.isNaN(lat)) ||
      (nbLng.trim() !== "" && Number.isNaN(lng))
    ) {
      setNbMsg("Latitude/Longitude inválidas.");
      return;
    }

    try {
      const resp = await fetch(`${API_BASE}/neighborhoods/`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders },
        body: JSON.stringify({
          name: nbName.trim(),
          city_id: Number(nbCityId),
          latitude: lat,
          longitude: lng,
        }),
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        setNbMsg(data?.detail || "Erro ao cadastrar bairro.");
        return;
      }

      const saved = await resp.json();
      setNeighborhoods((prev) => [...prev, saved]);

      setNbName("");
      setNbLat("");
      setNbLng("");
      setNbSuggestions([]);
      setNbMsg("Bairro cadastrado com sucesso!");
    } catch (err) {
      console.error(err);
      setNbMsg("Não foi possível conectar ao servidor.");
    }
  };

  const handleDeleteNeighborhood = async (id) => {
    const ok = window.confirm("Tem certeza que deseja excluir este bairro?");
    if (!ok) return;

    try {
      const resp = await fetch(`${API_BASE}/neighborhoods/${id}`, {
        method: "DELETE",
        headers: { ...authHeaders },
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        alert(
          data?.detail ||
            "Não foi possível excluir o bairro (verifique vínculos)."
        );
        return;
      }

      setNeighborhoods((prev) => prev.filter((nb) => nb.id !== id));
    } catch (err) {
      console.error(err);
      alert("Erro ao conectar ao servidor.");
    }
  };

  // ===== ADMIN: CAMINHÕES =====
  const handleCreateVehicle = async () => {
    setVehicleMsg("");

    if (!newVehicleName.trim()) {
      setVehicleMsg("Informe um nome para o caminhão.");
      return;
    }

    try {
      const resp = await fetch(`${API_BASE}/vehicles/`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders },
        body: JSON.stringify({
          name: newVehicleName.trim(),
          plate: newVehiclePlate.trim() || null,
          active: 1,
        }),
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        setVehicleMsg(data?.detail || "Erro ao cadastrar caminhão.");
        return;
      }

      const saved = await resp.json();
      setVehicles((prev) => [...prev, saved]);
      setNewVehicleName("");
      setNewVehiclePlate("");
      setVehicleMsg("Caminhão cadastrado com sucesso!");
    } catch (err) {
      console.error(err);
      setVehicleMsg("Não foi possível conectar ao servidor.");
    }
  };

  const handleDeleteVehicle = async (id) => {
    const ok = window.confirm(
      "Tem certeza que deseja excluir este caminhão? (remova vínculos antes, se houver)"
    );
    if (!ok) return;

    try {
      const resp = await fetch(`${API_BASE}/vehicles/${id}`, {
        method: "DELETE",
        headers: { ...authHeaders },
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        alert(
          data?.detail ||
            "Não foi possível excluir o caminhão. Talvez existam vínculos."
        );
        return;
      }

      setVehicles((prev) => prev.filter((v) => v.id !== id));
      setLinks((prev) => prev.filter((l) => l.vehicle_id !== id));
    } catch (err) {
      console.error(err);
      alert("Erro ao conectar ao servidor.");
    }
  };

  // ===== ADMIN: VÍNCULOS =====
  const handleLinkRouteCityDay = async () => {
    setLinkMsg("");

    if (!linkRouteId || !linkCityId || linkWeekday === "") {
      setLinkMsg("Selecione rota, cidade e dia da semana.");
      return;
    }

    try {
      const resp = await fetch(`${API_BASE}/route-city-day/`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders },
        body: JSON.stringify({
          route_id: Number(linkRouteId),
          city_id: Number(linkCityId),
          weekday: Number(linkWeekday),
          vehicle_id: linkVehicleId ? Number(linkVehicleId) : null,
          neighborhood_id: linkNeighborhoodId
            ? Number(linkNeighborhoodId)
            : null,
        }),
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        setLinkMsg(data?.detail || "Erro ao vincular rota/cidade/dia.");
        return;
      }

      const saved = await resp.json();
      setLinks((prev) => [...prev, saved]);
      setLinkMsg("Vínculo criado com sucesso!");
    } catch (err) {
      console.error(err);
      setLinkMsg("Não foi possível conectar ao servidor.");
    }
  };

  const handleDeleteLink = async (id) => {
    const ok = window.confirm(
      "Tem certeza que deseja remover este vínculo de rota/cidade/dia?"
    );
    if (!ok) return;

    try {
      const resp = await fetch(`${API_BASE}/route-city-day/${id}`, {
        method: "DELETE",
        headers: { ...authHeaders },
      });

      if (!resp.ok) {
        const data = await resp.json().catch(() => null);
        alert(data?.detail || "Não foi possível excluir o vínculo.");
        return;
      }

      setLinks((prev) => prev.filter((l) => l.id !== id));
    } catch (err) {
      console.error(err);
      alert("Erro ao conectar ao servidor.");
    }
  };

  // ===================== RENDER =====================

  if (!token) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex justify-center items-start px-4 py-6">
      <div className="w-full max-w-5xl bg-slate-950 border border-emerald-900/60 rounded-2xl shadow-2xl shadow-black/40 p-6">
        {/* HEADER + ABAS */}
        <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500/20 border border-emerald-400/60">
                🚚
              </span>
              <span>Sistema de Rotas</span>
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              Consulta e administração de rotas por cidade, bairro, caminhão e
              dia da semana.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-700 rounded-full p-1">
              <button
                onClick={() => setActiveTab("consulta")}
                className={`px-4 py-1 text-sm rounded-full transition ${
                  activeTab === "consulta"
                    ? "bg-emerald-500 text-slate-950 font-semibold shadow-sm shadow-emerald-400/40"
                    : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                Consulta
              </button>
              <button
                onClick={() => setActiveTab("admin")}
                className={`px-4 py-1 text-sm rounded-full transition ${
                  activeTab === "admin"
                    ? "bg-emerald-500 text-slate-950 font-semibold shadow-sm shadow-emerald-400/40"
                    : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                Administração
              </button>
            </div>

            <button
              onClick={handleLogout}
              className="px-3 py-1 rounded-full text-xs font-semibold bg-red-500/90 hover:bg-red-600 text-slate-50 border border-red-300/60 transition"
            >
              Sair
            </button>
          </div>
        </header>

        {/* ==================== ABA CONSULTA ==================== */}
        {activeTab === "consulta" && (
          <div className="space-y-6">
            {/* BUSCA POR CIDADE/BAIRRO */}
            <section className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <div>
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <span className="h-6 w-1 rounded-full bg-emerald-500" />
                  Buscar por cidade ou bairro
                </h2>
                <p className="text-sm text-slate-400 ml-2">
                  Digite o nome de uma cidade ou bairro (ex.: Campinas, Centro,
                  São Paulo, Vila Mariana).
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  placeholder="Ex.: Campinas ou Centro"
                  value={cityQuery}
                  onChange={(e) => setCityQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  className="flex-1 min-w-[180px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  onClick={handleSearch}
                  disabled={loading}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 disabled:opacity-70 disabled:cursor-not-allowed text-slate-950 transition"
                >
                  {loading ? "Buscando..." : "Buscar"}
                </button>
                <button
                  onClick={handleClearCitySearch}
                  className="px-3 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600"
                >
                  Limpar
                </button>
              </div>

              {error && (
                <div className="mt-1 rounded-lg bg-red-900/70 text-red-50 text-sm px-3 py-2">
                  {error}
                </div>
              )}

              {result && (
                <div className="mt-2 space-y-2">
                  <h3 className="text-sm">
                    Resultado:{" "}
                    <span className="font-semibold text-emerald-300">
                      {result.city}{" "}
                      <span className="text-xs text-slate-400">
                        ({result.city_type})
                      </span>
                    </span>
                  </h3>

                  {result.routes.length === 0 ? (
                    <p className="text-sm text-slate-400">
                      Nenhuma rota cadastrada para esta cidade/bairro.
                    </p>
                  ) : (
                    <>
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm border-collapse">
                          <thead>
                            <tr className="border-b border-slate-700 bg-slate-900/70">
                              <th className="text-left py-2 px-2">Rota</th>
                              <th className="text-left py-2 px-2">
                                Bairro / Zona
                              </th>
                              <th className="text-left py-2 px-2">
                                Dia da semana
                              </th>
                              <th className="text-left py-2 px-2">
                                Caminhão
                              </th>
                            </tr>
                          </thead>
                          <tbody>
                            {result.routes.map((r, index) => (
                              <tr
                                key={index}
                                className="border-b border-slate-800 last:border-0"
                              >
                                <td className="py-2 px-2">{r.route_name}</td>
                                <td className="py-2 px-2">
                                  {r.neighborhood_name || "Cidade inteira"}
                                </td>
                                <td className="py-2 px-2">
                                  {WEEKDAYS[r.weekday] ?? r.weekday}
                                </td>
                                <td className="py-2 px-2">
                                  {r.vehicle_name
                                    ? `${r.vehicle_name}${
                                        r.vehicle_plate
                                          ? ` (${r.vehicle_plate})`
                                          : ""
                                      }`
                                    : "Sem caminhão definido"}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Mapa do resultado por cidade/bairro */}
                      <RouteCitiesMap data={result.routes} />
                    </>
                  )}
                </div>
              )}
            </section>

            {/* BUSCA POR DIA */}
            <section className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <div>
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <span className="h-6 w-1 rounded-full bg-emerald-500" />
                  Buscar por dia
                </h2>
                <p className="text-sm text-slate-400 ml-2">
                  Veja todas as cidades, bairros, caminhões e rotas que rodam em
                  um dia específico.
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <select
                  value={weekday}
                  onChange={(e) => setWeekday(e.target.value)}
                  className="min-w-[200px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">Selecione um dia</option>
                  <option value="0">Segunda-feira</option>
                  <option value="1">Terça-feira</option>
                  <option value="2">Quarta-feira</option>
                  <option value="3">Quinta-feira</option>
                  <option value="4">Sexta-feira</option>
                  <option value="5">Sábado</option>
                  <option value="6">Domingo</option>
                </select>

                <button
                  onClick={handleSearchByDay}
                  disabled={loadingDay}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 disabled:opacity-70 disabled:cursor-not-allowed text-slate-950 transition"
                >
                  {loadingDay ? "Buscando..." : "Buscar por dia"}
                </button>
                <button
                  onClick={handleClearDaySearch}
                  className="px-3 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600"
                >
                  Limpar
                </button>
              </div>

              {errorDay && (
                <div className="mt-1 rounded-lg bg-red-900/70 text-red-50 text-sm px-3 py-2">
                  {errorDay}
                </div>
              )}

              {resultByDay.length > 0 && (
                <div className="mt-2 space-y-2">
                  <h3 className="text-sm">
                    Rotas que rodam em{" "}
                    <span className="font-semibold text-emerald-300">
                      {WEEKDAYS[Number(weekday)]}
                    </span>
                  </h3>

                  <div className="overflow-x-auto">
                    <table className="w-full text-sm border-collapse">
                      <thead>
                        <tr className="border-b border-slate-700 bg-slate-900/70">
                          <th className="text-left py-2 px-2">Rota</th>
                          <th className="text-left py-2 px-2">Cidade</th>
                          <th className="text-left py-2 px-2">
                            Bairro / Zona
                          </th>
                          <th className="text-left py-2 px-2">Caminhão</th>
                        </tr>
                      </thead>
                      <tbody>
                        {resultByDay.map((r, index) => (
                          <tr
                            key={index}
                            className="border-b border-slate-800 last:border-0"
                          >
                            <td className="py-2 px-2">{r.route_name}</td>
                            <td className="py-2 px-2">{r.city_name}</td>
                            <td className="py-2 px-2">
                              {r.neighborhood_name || "Cidade inteira"}
                            </td>
                            <td className="py-2 px-2">
                              {r.vehicle_name
                                ? `${r.vehicle_name}${
                                    r.vehicle_plate
                                      ? ` (${r.vehicle_plate})`
                                      : ""
                                  }`
                                : "Sem caminhão"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Mapa das cidades/bairros que rodam nesse dia */}
                  <RouteCitiesMap data={resultByDay} />
                </div>
              )}
            </section>
          </div>
        )}

        {/* ==================== ABA ADMIN ==================== */}
        {activeTab === "admin" && (
          <div className="space-y-6">
            {/* INTRO */}
            <section className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-1">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <span className="h-6 w-1 rounded-full bg-emerald-500" />
                Administração
              </h2>
              <p className="text-sm text-slate-400 ml-2">
                Cadastre rotas, cidades, bairros, caminhões e vínculos. Tudo
                aqui aparece na aba Consulta.
              </p>
            </section>

            {/* ROTAS */}
            <section className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <h3 className="text-base font-semibold">Rotas</h3>

              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  placeholder="Nome da rota (ex.: Rota 01)"
                  value={newRouteName}
                  onChange={(e) => setNewRouteName(e.target.value)}
                  className="flex-1 min-w-[180px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="text"
                  placeholder="Descrição (opcional)"
                  value={newRouteDesc}
                  onChange={(e) => setNewRouteDesc(e.target.value)}
                  className="flex-1 min-w-[180px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  onClick={handleCreateRoute}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 transition text-slate-950"
                >
                  Salvar rota
                </button>
              </div>

              {routeMsg && (
                <div
                  className={`text-xs mt-1 ${
                    routeMsg.includes("sucesso")
                      ? "text-emerald-300"
                      : "text-rose-300"
                  }`}
                >
                  {routeMsg}
                </div>
              )}

              {routes.length > 0 && (
                <div className="mt-3 space-y-1 text-sm">
                  {routes.map((r) => (
                    <div
                      key={r.id}
                      className="flex items-center justify-between border-b border-slate-800 last:border-0 pb-1"
                    >
                      <span>{r.name}</span>
                      <button
                        onClick={() => handleDeleteRoute(r.id)}
                        className="px-2 py-1 text-xs rounded-md bg-rose-600 hover:bg-rose-700 text-rose-50"
                      >
                        Excluir
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* CIDADES */}
            <section className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <h3 className="text-base font-semibold">Cidades</h3>

              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  placeholder="Nome da cidade"
                  value={newCityName}
                  onChange={(e) => setNewCityName(e.target.value)}
                  className="flex-1 min-w-[180px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="text"
                  placeholder="UF (ex.: SP)"
                  value={newCityState}
                  onChange={(e) => setNewCityState(e.target.value)}
                  className="w-20 px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="text"
                  placeholder="Latitude"
                  value={newCityLat}
                  onChange={(e) => setNewCityLat(e.target.value)}
                  className="w-36 px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm"
                />
                <input
                  type="text"
                  placeholder="Longitude"
                  value={newCityLng}
                  onChange={(e) => setNewCityLng(e.target.value)}
                  className="w-36 px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm"
                />
                <button
                  onClick={handleGeocodeCity}
                  disabled={loadingCityGeo}
                  className="px-3 py-2 rounded-lg text-xs font-semibold bg-indigo-500 hover:bg-indigo-600 disabled:opacity-70 text-white"
                >
                  {loadingCityGeo ? "Buscando..." : "Buscar coordenadas"}
                </button>
                <button
                  onClick={handleCreateCity}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 transition text-slate-950"
                >
                  Salvar cidade
                </button>
              </div>

              {citySuggestions.length > 0 && (
                <div className="mt-2 text-xs bg-slate-900 border border-slate-700 rounded-lg p-2 space-y-1 max-h-40 overflow-auto">
                  <p className="text-slate-300 mb-1">
                    Sugestões encontradas (clique para aplicar as coordenadas):
                  </p>
                  {citySuggestions.map((s, idx) => (
                    <button
                      key={idx}
                      onClick={() => selectCitySuggestion(s)}
                      className="w-full text-left px-2 py-1 rounded-md hover:bg-slate-800"
                    >
                      {s.display_name}
                    </button>
                  ))}
                </div>
              )}

              {cityMsg && (
                <div
                  className={`text-xs mt-1 ${
                    cityMsg.includes("sucesso") || cityMsg.includes("aplicadas")
                      ? "text-emerald-300"
                      : "text-rose-300"
                  }`}
                >
                  {cityMsg}
                </div>
              )}

              {cities.length > 0 && (
                <div className="mt-3 space-y-1 text-sm">
                  {cities.map((c) => (
                    <div
                      key={c.id}
                      className="flex items-center justify-between border-b border-slate-800 last:border-0 pb-1"
                    >
                      <span>
                        {c.name}
                        {c.state ? ` (${c.state})` : ""}{" "}
                        {c.latitude != null && c.longitude != null && (
                          <span className="text-xs text-slate-400">
                            ({c.latitude.toFixed(5)}, {c.longitude.toFixed(5)})
                          </span>
                        )}
                      </span>
                      <button
                        onClick={() => handleDeleteCity(c.id)}
                        className="px-2 py-1 text-xs rounded-md bg-rose-600 hover:bg-rose-700 text-rose-50"
                      >
                        Excluir
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* BAIRROS */}
            <section className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <h3 className="text-base font-semibold">Bairros</h3>

              <div className="flex flex-wrap gap-2">
                <select
                  value={nbCityId}
                  onChange={(e) => setNbCityId(e.target.value)}
                  className="flex-1 min-w-[160px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">Selecione a cidade</option>
                  {cities.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>

                <input
                  type="text"
                  placeholder="Nome do bairro (ex.: Centro)"
                  value={nbName}
                  onChange={(e) => setNbName(e.target.value)}
                  className="flex-1 min-w-[180px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />

                <input
                  type="text"
                  placeholder="Latitude"
                  value={nbLat}
                  onChange={(e) => setNbLat(e.target.value)}
                  className="w-32 px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="text"
                  placeholder="Longitude"
                  value={nbLng}
                  onChange={(e) => setNbLng(e.target.value)}
                  className="w-32 px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />

                <button
                  onClick={handleGeocodeNeighborhood}
                  disabled={nbLoading}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-sky-500 hover:bg-sky-600 disabled:opacity-70 disabled:cursor-not-allowed transition text-slate-950"
                >
                  {nbLoading ? "Buscando..." : "Buscar coordenadas"}
                </button>

                <button
                  onClick={handleCreateNeighborhood}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 transition text-slate-950"
                >
                  Salvar bairro
                </button>
              </div>

              {nbMsg && (
                <div
                  className={`text-xs mt-1 ${
                    nbMsg.includes("sucesso")
                      ? "text-emerald-300"
                      : nbMsg.includes("preenchidas")
                      ? "text-sky-300"
                      : "text-rose-300"
                  }`}
                >
                  {nbMsg}
                </div>
              )}

              {nbSuggestions.length > 0 && (
                <div className="mt-2 text-xs bg-slate-900 border border-slate-700 rounded-lg p-2 space-y-1">
                  <p className="text-slate-300 mb-1">
                    Sugestões encontradas (clique para usar as coordenadas):
                  </p>
                  {nbSuggestions.map((sug, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleChooseSuggestion(sug)}
                      className="w-full text-left px-2 py-1 rounded-md hover:bg-slate-800"
                    >
                      {sug.display_name}{" "}
                      <span className="text-slate-400">
                        ({sug.latitude.toFixed(5)},{" "}
                        {sug.longitude.toFixed(5)})
                      </span>
                    </button>
                  ))}
                </div>
              )}

              {neighborhoods.length > 0 && (
                <div className="mt-3">
                  <h4 className="text-sm font-semibold mb-2">
                    Bairros cadastrados
                  </h4>
                  <div className="space-y-1 text-sm">
                    {neighborhoods.map((nb) => (
                      <div
                        key={nb.id}
                        className="flex items-center justify-between border-b border-slate-800 last:border-0 pb-1"
                      >
                        <span>
                          {getCityName(nb.city_id)} - {nb.name}{" "}
                          {nb.latitude != null && nb.longitude != null && (
                            <span className="text-xs text-slate-400">
                              ({nb.latitude.toFixed(5)},{" "}
                              {nb.longitude.toFixed(5)})
                            </span>
                          )}
                        </span>
                        <button
                          onClick={() => handleDeleteNeighborhood(nb.id)}
                          className="px-2 py-1 text-xs rounded-md bg-rose-600 hover:bg-rose-700 text-rose-50"
                        >
                          Excluir
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </section>

            {/* CAMINHÕES */}
            <section className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <h3 className="text-base font-semibold">Caminhões</h3>

              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  placeholder="Nome do caminhão (ex.: Caminhão 01)"
                  value={newVehicleName}
                  onChange={(e) => setNewVehicleName(e.target.value)}
                  className="flex-1 min-w-[180px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <input
                  type="text"
                  placeholder="Placa (opcional)"
                  value={newVehiclePlate}
                  onChange={(e) => setNewVehiclePlate(e.target.value)}
                  className="w-40 px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  onClick={handleCreateVehicle}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 transition text-slate-950"
                >
                  Salvar caminhão
                </button>
              </div>

              {vehicleMsg && (
                <div
                  className={`text-xs mt-1 ${
                    vehicleMsg.includes("sucesso")
                      ? "text-emerald-300"
                      : "text-rose-300"
                  }`}
                >
                  {vehicleMsg}
                </div>
              )}

              {vehicles.length > 0 && (
                <div className="mt-3 space-y-1 text-sm">
                  {vehicles.map((v) => (
                    <div
                      key={v.id}
                      className="flex items-center justify-between border-b border-slate-800 last:border-0 pb-1"
                    >
                      <span>
                        {v.name}
                        {v.plate ? ` (${v.plate})` : ""}{" "}
                        {v.active === 0 && (
                          <span className="text-xs text-slate-400">
                            (inativo)
                          </span>
                        )}
                      </span>
                      <button
                        onClick={() => handleDeleteVehicle(v.id)}
                        className="px-2 py-1 text-xs rounded-md bg-rose-600 hover:bg-rose-700 text-rose-50"
                      >
                        Excluir
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* VÍNCULOS */}
            <section className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <h3 className="text-base font-semibold">
                Vincular rota + cidade + bairro (opcional) + dia + caminhão
              </h3>

              <div className="flex flex-wrap gap-2">
                {/* ROTA */}
                <select
                  value={linkRouteId}
                  onChange={(e) => setLinkRouteId(e.target.value)}
                  className="flex-1 min-w-[160px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">Selecione a rota</option>
                  {routes.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name}
                    </option>
                  ))}
                </select>

                {/* CIDADE */}
                <select
                  value={linkCityId}
                  onChange={(e) => {
                    setLinkCityId(e.target.value);
                    setLinkNeighborhoodId("");
                  }}
                  className="flex-1 min-w-[160px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">Selecione a cidade</option>
                  {cities.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                      {c.state ? ` (${c.state})` : ""}
                    </option>
                  ))}
                </select>

                {/* BAIRRO (opcional) */}
                <select
                  value={linkNeighborhoodId}
                  onChange={(e) => setLinkNeighborhoodId(e.target.value)}
                  className="min-w-[160px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">Cidade inteira (sem bairro)</option>
                  {neighborhoods
                    .filter((nb) => nb.city_id === Number(linkCityId))
                    .map((nb) => (
                      <option key={nb.id} value={nb.id}>
                        {nb.name}
                      </option>
                    ))}
                </select>

                {/* DIA DA SEMANA */}
                <select
                  value={linkWeekday}
                  onChange={(e) => setLinkWeekday(e.target.value)}
                  className="min-w-[140px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">Dia da semana</option>
                  <option value="0">Segunda-feira</option>
                  <option value="1">Terça-feira</option>
                  <option value="2">Quarta-feira</option>
                  <option value="3">Quinta-feira</option>
                  <option value="4">Sexta-feira</option>
                  <option value="5">Sábado</option>
                  <option value="6">Domingo</option>
                </select>

                {/* CAMINHÃO */}
                <select
                  value={linkVehicleId}
                  onChange={(e) => setLinkVehicleId(e.target.value)}
                  className="min-w-[160px] px-3 py-2 rounded-lg border border-slate-700 bg-slate-950 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">Sem caminhão específico</option>
                  {vehicles.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.name} {v.plate ? `(${v.plate})` : ""}
                    </option>
                  ))}
                </select>

                <button
                  onClick={handleLinkRouteCityDay}
                  className="px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 hover:bg-emerald-600 transition text-slate-950"
                >
                  Salvar vínculo
                </button>
              </div>

              {linkMsg && (
                <div
                  className={`text-xs mt-1 ${
                    linkMsg.includes("sucesso")
                      ? "text-emerald-300"
                      : "text-rose-300"
                  }`}
                >
                  {linkMsg}
                </div>
              )}

              {/* LISTA DE VÍNCULOS */}
              <div className="mt-3">
                <h4 className="text-sm font-semibold mb-2">
                  Vínculos cadastrados
                </h4>

                {links.length === 0 ? (
                  <p className="text-xs text-slate-400">
                    Nenhum vínculo cadastrado ainda.
                  </p>
                ) : (
                  <div className="space-y-1 text-sm">
                    {links.map((l) => (
                      <div
                        key={l.id}
                        className="flex items-center justify-between border-b border-slate-800 last:border-0 pb-1"
                      >
                        <span>
                          {getRouteName(l.route_id)} {" → "}{" "}
                          {getCityName(l.city_id)}
                          {l.neighborhood_id && (
                            <> - {getNeighborhoodName(l.neighborhood_id)}</>
                          )}{" "}
                          {" ("}
                          {WEEKDAYS[l.weekday] ?? l.weekday}
                          {")"}{" "}
                          • Caminhão: {getVehicleName(l.vehicle_id)}
                        </span>
                        <button
                          onClick={() => handleDeleteLink(l.id)}
                          className="px-2 py-1 text-xs rounded-md bg-rose-600 hover:bg-rose-700 text-rose-50"
                        >
                          Remover
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <p className="mt-1 text-[11px] text-slate-500">
                  Use esta lista para corrigir vínculos errados rapidamente.
                </p>
              </div>
            </section>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
